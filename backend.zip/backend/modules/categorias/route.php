<?php
declare(strict_types=1);

// backend/modules/categorias/route.php

function route_categorias(string $action): bool
{
    switch ($action) {
        case 'cat_listar':
            require __DIR__ . '/obtener_categorias.php';
            return true;

        case 'cat_crear':
            require __DIR__ . '/agregar_categoria.php';
            return true;

        case 'cat_actualizar':
            require __DIR__ . '/editar_categoria.php';
            return true;

        case 'cat_eliminar':
            require __DIR__ . '/eliminar_categoria.php';
            return true;

        case 'cat_historial':
            require __DIR__ . '/obtener_historial.php';
            return true;
    }

    return false;
}
