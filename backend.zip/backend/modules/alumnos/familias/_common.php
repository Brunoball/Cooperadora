<?php
declare(strict_types=1);

/**
 * Helpers y DB compartidos por todos los endpoints de familias (ALUMNOS).
 * ✅ Compatible con db.php que guarde PDO en $GLOBALS['pdo'] o en $pdo global.
 */

require_once __DIR__ . '/../../../config/db.php';

/**
 * Devuelve una instancia válida de PDO o corta con error claro.
 */
function fam_pdo(): PDO
{
    // 1) Preferido: db.php guarda la conexión en $GLOBALS['pdo']
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
        return $GLOBALS['pdo'];
    }

    // 2) Compat: db.php define $pdo en el scope global
    global $pdo;
    if (isset($pdo) && $pdo instanceof PDO) {
        // sincronizamos por si otros módulos usan $GLOBALS
        $GLOBALS['pdo'] = $pdo;
        return $pdo;
    }

    // 3) No hay conexión -> error
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'exito' => false,
        'mensaje' => 'DB no inicializada. No se encontró PDO ni en $GLOBALS["pdo"] ni en $pdo (global). Revisá backend/config/db.php y su ruta.',
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function fam_json(array $arr, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

function fam_str(mixed $v): string
{
    return trim((string)$v);
}

function fam_int_or_null(mixed $v): ?int
{
    return ($v === null || $v === '' || !isset($v)) ? null : (int)$v;
}

function fam_read_json(): array
{
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}