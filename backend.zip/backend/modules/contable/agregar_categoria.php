<?php
// backend/modules/contable/agregar_categoria.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';

header('Content-Type: application/json; charset=utf-8');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['exito' => false, 'mensaje' => 'Método no permitido. Usá POST.']);
        exit;
    }

    if (!($pdo instanceof PDO)) {
        throw new RuntimeException('Conexión PDO no disponible.');
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES utf8mb4");

    // Admite JSON o form-url-encoded
    $raw = json_decode(file_get_contents('php://input'), true);
    if (!is_array($raw)) {
        $raw = $_POST;
    }

    $nombre = strtoupper(trim((string)($raw['nombre'] ?? '')));
    // Normalizar espacios múltiples
    $nombre = preg_replace('/\s+/', ' ', $nombre ?? '');
    if ($nombre === '') {
        throw new RuntimeException('INGRESÁ LA NUEVA CATEGORÍA.');
    }
    if (mb_strlen($nombre) > 120) {
        throw new RuntimeException('LA CATEGORÍA NO PUEDE SUPERAR 120 CARACTERES.');
    }

    // Inserta si no existe; si ya existe, hace no-op para mantener la UNIQUE.
    // IMPORTANTE: sólo referenciamos la TABLA, no el esquema.
    $sql = "INSERT INTO contable_categoria (nombre_categoria)
            VALUES (:n)
            ON DUPLICATE KEY UPDATE nombre_categoria = VALUES(nombre_categoria)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':n' => $nombre]);

    // Si insertó, devuelve el nuevo id; si no, buscamos el existente.
    $id = (int)$pdo->lastInsertId();
    if ($id === 0) {
        $q = $pdo->prepare(
            "SELECT id_cont_categoria
             FROM contable_categoria
             WHERE nombre_categoria = :n
             LIMIT 1"
        );
        $q->execute([':n' => $nombre]);
        $id = (int)($q->fetchColumn() ?: 0);
    }

    if ($id <= 0) {
        throw new RuntimeException('No se pudo obtener el ID de la categoría.');
    }

    echo json_encode([
        'exito'  => true,
        'id'     => $id,
        'nombre' => $nombre,
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    // mantenemos 200 para manejo uniforme en frontend
    http_response_code(200);
    echo json_encode([
        'exito'   => false,
        'mensaje' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
}
