<?php
// backend/routes/api.php

declare(strict_types=1);

/* ========= CORS ========= */
$origin = $_SERVER['HTTP_ORIGIN'] ?? '*';
header("Access-Control-Allow-Origin: $origin");
header('Vary: Origin');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-Session');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

date_default_timezone_set('America/Argentina/Cordoba');
mb_internal_encoding('UTF-8');

$action = (string)($_GET['action'] ?? '');
$action = trim($action);

/* ========= Helpers ========= */
function json_out(array $payload, int $code = 200): void {
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ========= Includes (si falla alguno, antes era 500 “mudo”). Ahora lo atrapamos) ========= */
try {
    require_once __DIR__ . '/../modules/login/route.php';
    require_once __DIR__ . '/../modules/alumnos/route.php';
    require_once __DIR__ . '/../modules/global/route.php';
    require_once __DIR__ . '/../modules/cuotas/route.php';
    require_once __DIR__ . '/../modules/contable/route.php';
    require_once __DIR__ . '/../modules/tipos_documentos/route.php';
    require_once __DIR__ . '/../modules/categorias/route.php';
} catch (Throwable $e) {
    error_log("API INCLUDE ERROR: " . $e->getMessage() . "\n" . $e->getTraceAsString());
    json_out([
        'exito' => false,
        'mensaje' => 'Error interno cargando rutas. Revisá la consola del servidor.',
    ], 500);
}

/* ========= Router ========= */
try {
    if ($action === '') {
        json_out(['exito' => false, 'mensaje' => 'Falta action'], 400);
    }

    if (function_exists('route_login') && route_login($action))  exit;
    if (function_exists('route_alumnos') && route_alumnos($action)) exit;
    if (function_exists('route_global') && route_global($action))  exit;
    if (function_exists('route_cuotas') && route_cuotas($action))  exit;
    if (function_exists('route_contable') && route_contable($action)) exit;
    if (function_exists('route_tipos_documentos') && route_tipos_documentos($action)) exit;
    if (function_exists('route_categorias') && route_categorias($action)) exit;

    json_out([
        'exito' => false,
        'mensaje' => 'Acción no válida: ' . $action,
    ], 404);

} catch (Throwable $e) {
    // ✅ ahora sí: 500 real + log
    error_log("API ROUTER ERROR (action={$action}): " . $e->getMessage() . "\n" . $e->getTraceAsString());
    json_out([
        'exito' => false,
        'mensaje' => 'Error interno del servidor. Revisá la consola del backend (php -S).',
        // si querés ver el detalle en dev, descomentá:
        // 'debug' => $e->getMessage(),
    ], 500);
}