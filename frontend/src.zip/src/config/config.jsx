const BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:3001";

export default BASE_URL;


//Hostinger: https://cooperadora.ipet50.edu.ar/api/routes
//Local: http://localhost:3001

//php -c "C:\php\php.ini" -S localhost:3001


//npx playwright test --project=chromium --workers=1 --reporter=list

